export interface Stock {
  id: number,
  name: string,
  cuantity: number,
  existance: number
}